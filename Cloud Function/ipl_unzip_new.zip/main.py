from google.cloud import storage
from zipfile import ZipFile
from zipfile import is_zipfile
import io

def zipextract(request):

    frombucketname = "ipl_landing"
    srcpath = "compressed/new.zip"
    tobucketname = "ipl_landing"
    destpath = "extract/new"
    storage_client = storage.Client()
    srcbucket = storage_client.get_bucket(frombucketname)
    destbucket = storage_client.get_bucket(tobucketname)
    src_blob_pathname = srcpath
    dest_blob_pathname = destpath

    blob = srcbucket.blob(src_blob_pathname)
    zipbytes = io.BytesIO(blob.download_as_string())

    if is_zipfile(zipbytes):
        with ZipFile(zipbytes, 'r') as myzip:
            for contentfilename in myzip.namelist():
                contentfile = myzip.read(contentfilename)
                blob = destbucket.blob(dest_blob_pathname + "/" + contentfilename)
                blob.upload_from_string(contentfile)

