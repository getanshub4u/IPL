# Imports the BigQuery client library
from google.cloud import bigquery

def extract_job(request):
    
    project_name = "my-ipl-data"
    bucket_name = 'ipl_report_source'
    
    dataset_name = "IPL_DATA"
    
    table_name = "IPL_DETAIL_INT"
    #destination_uri = "gs://{}/{}".format(bucket_name, "bq_export.csv.gz")
    destination_url = "gs://{}/{}".format(bucket_name, "ipl_src/IPL_DETAIL_INT.csv")
    bq_client = bigquery.Client()
    #dataset = bq_client.dataset(dataset_name, project=project_name)
    dataset = bigquery.DatasetReference(project_name, dataset_name)
    table_to_export = dataset.table(table_name)
    #job_config = bigquery.job.ExtractJobConfig()
    #job_config.compression = bigquery.Compression.GZIP
    extract_job = bq_client.extract_table(
        table_to_export,
        destination_url,
        # Location must match that of the source table.
        location="US",
        #job_config=job_config,
    )  
    return "Job with ID {} started exporting data from {}.{} to {}".format(extract_job.job_id, dataset_name, table_name, destination_url)